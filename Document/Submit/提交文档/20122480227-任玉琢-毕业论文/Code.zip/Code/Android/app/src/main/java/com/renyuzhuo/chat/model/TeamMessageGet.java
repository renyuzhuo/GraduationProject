package com.renyuzhuo.chat.model;

/**
 * Created by RENYUZHUO on 2016/4/29.
 */
public class TeamMessageGet {
}
