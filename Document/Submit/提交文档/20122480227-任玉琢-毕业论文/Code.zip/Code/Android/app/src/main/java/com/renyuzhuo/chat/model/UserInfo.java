package com.renyuzhuo.chat.model;

/**
 * Created by RENYUZHUO on 2016/4/10.
 */
public class UserInfo {
    private int id;
    private String token;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
