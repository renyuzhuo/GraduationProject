# Chat

### 新建项目，

初始化选择界面布局，初步搭建架构
![Android进度](https://coding.net/api/project/249656/files/565317/imagePreview) 