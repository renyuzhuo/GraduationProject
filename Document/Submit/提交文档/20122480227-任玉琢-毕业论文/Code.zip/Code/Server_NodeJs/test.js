var moment = require('moment');
console.log('start server time: ' + moment().utcOffset('+08:00'));