/*
exports.host = '10.9.1.188';
exports.port = 3306;
exports.user = '9D0rRPgxFck99wg7';
exports.password = 'HBhphHCBXgyagsHf';
exports.database = 'cf_6f523eb9_0961_4905_9233_e9e84bbe5518';
exports.redisip = '10.9.21.212';
exports.redisport = 5140;
*/
///*
exports.host = 'localhost';
exports.port = 3306;
exports.user = 'root';
exports.password = 'root';
exports.database = 'chat';
exports.redisip = '127.0.0.1';
exports.redisport = 6379;
//*/

// exports.redispassword = '0601aa0d-339a-453a-b102-65969ce794c3';
